i = 0

while i < 100:
    print(i)
    a = 0
    i += 1

print(a)