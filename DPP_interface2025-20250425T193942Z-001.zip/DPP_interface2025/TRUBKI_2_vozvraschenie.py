import re
from collections import Counter


def analyze_flags(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()

    # Находим все строки данных
    lines = content.strip().split('\n')

    # Создаем счетчик комбинаций
    combinations = Counter()
    total_lines = 0

    # Анализируем каждую строку
    for line in lines:
        # Пропускаем строки с инициализацией
        if "initialized" in line or "started" in line or line.strip() == "":
            continue

        # Разделяем строку на значения
        values = line.split(';')

        # Проверяем, достаточно ли полей в строке
        if len(values) >= 42:  # Учитываем, что должно быть минимум 42 поля для флагов
            flag0 = int(values[37])
            flag1 = int(values[38])
            flag2 = int(values[39])
            flag3 = int(values[40])
            flag4 = int(values[41])

            # Формируем комбинацию флагов
            flag_combination = f"{flag0}{flag1}{flag2}{flag3}{flag4}"
            combinations[flag_combination] += 1
            total_lines += 1

    # Сортировка результатов по частоте (в порядке убывания)
    sorted_combinations = sorted(combinations.items(), key=lambda x: x[1], reverse=True)

    print(f"Всего проанализировано строк с флагами: {total_lines}")
    print("\nРаспределение комбинаций флагов:")

    for combination, count in sorted_combinations:
        # Форматирование вывода для наглядности
        percentage = (count / total_lines) * 100 if total_lines > 0 else 0
        print(
            f"flag0={combination[0]}, flag1={combination[1]}, flag2={combination[2]}, flag3={combination[3]}, flag4={combination[4]}: {count} раз ({percentage:.1f}%)")

    # Также выведем статистику по каждому отдельному флагу
    print("\nСтатистика по отдельным флагам:")
    for i in range(5):
        ones_count = sum(count for comb, count in combinations.items() if comb[i] == '1')
        percentage = (ones_count / total_lines) * 100 if total_lines > 0 else 0
        print(f"flag{i}=1: {ones_count} раз ({percentage:.1f}%)")


# Код для работы со структурой packet
def generate_packet_line(packet):
    """Генерирует строку данных из структуры packet"""
    values = []
    values.append(str(packet['time']))
    values.append(str(packet['pressure']))
    values.append(str(packet['temperature']))
    values.append(str(packet['mx']))
    values.append(str(packet['my']))
    values.append(str(packet['mz']))
    values.append(str(packet['gx']))
    values.append(str(packet['gy']))
    values.append(str(packet['gz']))
    values.append(str(packet['ax']))
    values.append(str(packet['ay']))
    values.append(str(packet['az']))
    # Добавляем adc_values (5 значений)
    for adc in packet['adc_values']:
        values.append(str(adc))
    # Добавляем cbks (15 значений) - первые 5 значений из cbks
    for i in range(5):
        values.append(str(packet['cbks'][i]))
    # Добавляем callback_times (5 значений)
    for cb_time in packet['callback_times']:
        values.append(str(cb_time))
    # Добавляем флаги
    values.append(str(packet['flag0']))
    values.append(str(packet['flag1']))
    values.append(str(packet['flag2']))
    values.append(str(packet['flag3']))
    values.append(str(packet['flag4']))

    return ';'.join(values)


# Пример использования для одного пакета
def analyze_single_packet(packet):
    flag_combination = f"{packet['flag0']}{packet['flag1']}{packet['flag2']}{packet['flag3']}{packet['flag4']}"
    print(
        f"Комбинация флагов для пакета: flag0={packet['flag0']}, flag1={packet['flag1']}, flag2={packet['flag2']}, flag3={packet['flag3']}, flag4={packet['flag4']}")
    print(f"Строковое представление комбинации: {flag_combination}")


# Пример анализа нескольких пакетов
def analyze_packets(packets):
    combinations = Counter()

    for packet in packets:
        flag_combination = f"{packet['flag0']}{packet['flag1']}{packet['flag2']}{packet['flag3']}{packet['flag4']}"
        combinations[flag_combination] += 1

    # Сортировка результатов по частоте (в порядке убывания)
    sorted_combinations = sorted(combinations.items(), key=lambda x: x[1], reverse=True)

    print(f"Всего проанализировано пакетов: {len(packets)}")
    print("\nРаспределение комбинаций флагов:")

    for combination, count in sorted_combinations:
        # Форматирование вывода для наглядности
        percentage = (count / len(packets)) * 100 if len(packets) > 0 else 0
        print(
            f"flag0={combination[0]}, flag1={combination[1]}, flag2={combination[2]}, flag3={combination[3]}, flag4={combination[4]}: {count} раз ({percentage:.1f}%)")


# Пример использования:
if __name__ == "__main__":
    # Если вы хотите проанализировать файл с логами:
    analyze_flags(r"C:\Users\snnse\OneDrive\Рабочий стол\LOG.txt")

    # Пример анализа одного пакета
    packet = {
        'time': 66666,
        'pressure': 78.7,
        'temperature': 656.6,
        'mx': 554,
        'my': 545,
        'mz': 54,
        'gx': 594.0,
        'gy': 6.04,
        'gz': 644.0,
        'ax': 123,
        'ay': 343,
        'az': 954,
        'flag0': 1,
        'flag1': 1,
        'flag2': 1,
        'flag3': 1,
        'flag4': 0,
        'adc_values': [1, 2, 3, 4, 5],
        'cbks': [44, 54, 77, 54, 6, 43, 11, 32, 77, 64, 111, 73, 23, 45, 12],
        'callback_times': [12121, 222343, 543345, 53223, 5434]
    }

    analyze_single_packet(packet)

    # Если у вас есть несколько пакетов:
    packets = [
        packet,
        # Добавьте другие пакеты при необходимости
    ]

    # Генерируем строку для пакета (если вам нужно сохранить пакет в формате лога)
    packet_line = generate_packet_line(packet)
    print("\nСгенерированная строка для пакета:")
    print(packet_line)