import serial
import struct
import time
from datetime import datetime

# Параметры COM-порта
COM_PORT = 'COM11'
BAUD_RATE = 9600

# Значение преамбулы
PREAMBLE = 2704

# Размер структуры в байтах (рассчитаем его после определения формата)
def calculate_struct_size():
    # Размеры отдельных элементов
    uint32_size = 4
    float_size = 4
    int16_size = 2
    bool_size = 1
    uint16_size = 2
    uint8_size = 1

    # Расчет общего размера
    total = 0
    total += uint32_size  # preambula
    total += uint32_size  # time
    total += float_size  # pressure
    total += float_size  # temperature
    total += 3 * int16_size  # mx, my, mz
    total += 3 * float_size  # gx, gy, gz
    total += 3 * float_size  # ax, ay, az
    total += 5 * bool_size  # flag0, flag1, flag2, flag3, flag4
    total += 5 * uint16_size  # adc_values[5]
    total += 15 * uint8_size  # cbks[15]
    total += 5 * uint32_size  # callback_times[5]

    return total+4


STRUCT_SIZE = calculate_struct_size()
print(f"Расчетный размер структуры данных: {STRUCT_SIZE} байт")


# Функция для распаковки отдельных частей структуры
def unpack_packet(data):
    index = 0

    # Распаковка преамбулы
    preambula = struct.unpack('<I', data[index:index + 4])[0]
    index += 4

    # Распаковка времени
    packet_time = struct.unpack('<I', data[index:index + 4])[0]
    index += 4

    # Распаковка давления и температуры
    pressure = struct.unpack('<f', data[index:index + 4])[0]
    index += 4
    temperature = struct.unpack('<f', data[index:index + 4])[0]
    index += 4

    # Распаковка данных магнитометра
    mx = struct.unpack('<h', data[index:index + 2])[0]
    index += 2
    my = struct.unpack('<h', data[index:index + 2])[0]
    index += 2
    mz = struct.unpack('<h', data[index:index + 2])[0]
    index += 4

    # Распаковка данных гироскопа
    gx = struct.unpack('<f', data[index:index + 4])[0]
    index += 4
    gy = struct.unpack('<f', data[index:index + 4])[0]
    index += 4
    gz = struct.unpack('<f', data[index:index + 4])[0]
    index += 4

    # Распаковка данных акселерометра
    ax = struct.unpack('<f', data[index:index + 4])[0]
    index += 4
    ay = struct.unpack('<f', data[index:index + 4])[0]
    index += 4
    az = struct.unpack('<f', data[index:index + 4])[0]
    index += 4

    # Распаковка флагов
    flags = []
    for i in range(5):
        flag = struct.unpack('<B', data[index:index + 1])[0]
        flags.append(bool(flag))
        index += 1
    index += 1
    # Распаковка значений АЦП
    adc_values = []
    for i in range(5):
        adc_value = struct.unpack('<H', data[index:index + 2])[0]
        adc_values.append(adc_value)
        index += 2

    # Распаковка callbacks
    cbks = []
    for i in range(15):
        cbk = struct.unpack('<B', data[index:index + 1])[0]
        cbks.append(cbk)
        index += 1
    index += 1

    # Распаковка callback_times
    callback_times = []
    for i in range(5):
        callback_time = struct.unpack('<I', data[index:index + 4])[0]
        callback_times.append(callback_time)
        index += 4

    return {
        'preambula': preambula,
        'time': packet_time,
        'pressure': pressure,
        'temperature': temperature,
        'mx': mx, 'my': my, 'mz': mz,
        'gx': gx, 'gy': gy, 'gz': gz,
        'ax': ax, 'ay': ay, 'az': az,
        'flags': flags,
        'adc_values': adc_values,
        'cbks': cbks,
        'callback_times': callback_times
    }


# Функция для поиска преамбулы в буфере
def find_preamble(buffer):
    for i in range(len(buffer) - 3):
        if struct.unpack('<I', buffer[i:i + 4])[0] == PREAMBLE:
            return i
    return -1


# Функция для проверки валидности float-значений
def is_valid_float(value):
    return not (value != value or value == float('inf') or value == float('-inf'))


# Функция для форматирования данных
def format_data(data):
    # Проверка валидности float-значений
    for key in ['pressure', 'temperature', 'gx', 'gy', 'gz', 'ax', 'ay', 'az']:
        if not is_valid_float(data[key]):
            print(f"Предупреждение: Невалидное значение для {key}: {data[key]}")
            data[key] = 0.0  # Заменяем невалидные значения на 0

    # Преобразуем флаги в строку битов
    flags_str = ''.join(['1' if flag else '0' for flag in data['flags']])

    # Форматирование данных для записи
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    formatted_data = (
        f"{current_time}\t"
        f"{data['time']}\t"
        f"{data['pressure']:.2f}\t"
        f"{data['temperature']:.2f}\t"
        f"({data['mx']}, {data['my']}, {data['mz']})\t"
        f"({data['gx']:.4f}, {data['gy']:.4f}, {data['gz']:.4f})\t"
        f"({data['ax']:.4f}, {data['ay']:.4f}, {data['az']:.4f})\t"
        f"{flags_str}\t"
        f"{data['adc_values']}\t"
        f"{data['cbks']}\t"
        f"{data['callback_times']}\n"
    )

    return formatted_data


def read_data():
    COM_PORT = 'COM11'
    BAUD_RATE = 9600
    try:
        ser = serial.Serial(COM_PORT, BAUD_RATE, timeout=1)
        print(f"COM-порт {COM_PORT} успешно открыт")
    except serial.SerialException as e:
        print(f"Ошибка при открытии COM-порта {COM_PORT}: {e}")
        return
    output_file = f"lora_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(output_file, 'w') as f:
            f.write("Время записи\tВремя пакета\tДавление\tТемпература\tМагнитометр (x,y,z)\tГироскоп (x,y,z)\t"
                    "Акселерометр (x,y,z)\tФлаги\tЗначения АЦП\tCallbacks\tCallback Times\n")

            print(f"Прием данных на {COM_PORT} со скоростью {BAUD_RATE} бод, запись в {output_file}")

            buffer = bytearray()

            while True:
                if ser.in_waiting > 0:
                    new_data = ser.read(ser.in_waiting)
                    buffer.extend(new_data)
                else:
                    time.sleep(0.1)
                    continue

                while True:
                    preamble_index = find_preamble(buffer)

                    if preamble_index == -1:
                        #последние байты на случай разделения преамбулы
                        if len(buffer) > 3:
                            buffer = buffer[-3:]
                        break

                    # Если преамбула не в начале, обрезаем буфер
                    if preamble_index > 0:
                        buffer = buffer[preamble_index:]

                    # Проверяем, есть ли у нас полный пакет
                    if len(buffer) < STRUCT_SIZE:
                        break

                    packet_data = buffer[:STRUCT_SIZE]
                    # print(list(packet_data))
                    buffer = buffer[STRUCT_SIZE:]

                    try:
                        data = unpack_packet(packet_data)

                        if data['preambula'] != PREAMBLE:
                            print(f"Предупреждение: Неверная преамбула: {data['preambula']}")
                            continue

                        formatted_data = format_data(data)

                        return data

                        f.write(formatted_data)
                        f.flush()

                    except Exception as e:
                        print(f"Ошибка распаковки данных: {e}")
                        continue

    except KeyboardInterrupt:
        print("\nСкрипт остановлен пользователем")
    except Exception as e:
        print(f"Ошибка: {e}")
    finally:
        ser.close()
        print(f"COM-порт {COM_PORT} закрыт")




def main():
    try:
        # Открываем COM-порт
        ser = serial.Serial(COM_PORT, BAUD_RATE, timeout=1)
        print(f"COM-порт {COM_PORT} успешно открыт")
    except serial.SerialException as e:
        print(f"Ошибка при открытии COM-порта {COM_PORT}: {e}")
        return

    # Создаем файл для записи
    output_file = f"lora_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(output_file, 'w') as f:
            # Записываем заголовок
            f.write("Время записи\tВремя пакета\tДавление\tТемпература\tМагнитометр (x,y,z)\tГироскоп (x,y,z)\t"
                    "Акселерометр (x,y,z)\tФлаги\tЗначения АЦП\tCallbacks\tCallback Times\n")

            print(f"Прием данных на {COM_PORT} со скоростью {BAUD_RATE} бод, запись в {output_file}")
            print("Нажмите Ctrl+C для остановки")

            # Буфер для хранения частичных данных
            buffer = bytearray()

            while True:
                # Читаем доступные данные
                if ser.in_waiting > 0:
                    new_data = ser.read(ser.in_waiting)
                    buffer.extend(new_data)
                else:
                    time.sleep(0.1)  # Ждем немного, если данных нет
                    continue

                # Обрабатываем полные пакеты
                while True:
                    # Ищем преамбулу в буфере
                    preamble_index = find_preamble(buffer)

                    if preamble_index == -1:
                        # Преамбула не найдена, сохраняем последние байты на случай разделения преамбулы
                        if len(buffer) > 3:
                            buffer = buffer[-3:]
                        break

                    # Если преамбула не в начале, обрезаем буфер
                    if preamble_index > 0:
                        buffer = buffer[preamble_index:]

                    # Проверяем, есть ли у нас полный пакет
                    if len(buffer) < STRUCT_SIZE:
                        break

                    # У нас есть полный пакет с корректной преамбулой
                    packet_data = buffer[:STRUCT_SIZE]
                    print(list(packet_data))
                    buffer = buffer[STRUCT_SIZE:]  # Удаляем обработанные данные

                    # Распаковываем структуру по частям
                    try:
                        data = unpack_packet(packet_data)

                        # Дополнительная проверка преамбулы
                        if data['preambula'] != PREAMBLE:
                            print(f"Предупреждение: Неверная преамбула: {data['preambula']}")
                            continue

                        # Форматируем данные
                        formatted_data = format_data(data)

                        # Выводим отладочную информацию о float-значениях
                        print(data)

                        # Записываем в файл
                        f.write(formatted_data)
                        f.flush()  # Убеждаемся, что данные записаны на диск

                    except Exception as e:
                        print(f"Ошибка распаковки данных: {e}")
                        # Пропускаем этот пакет
                        continue


    except KeyboardInterrupt:
        print("\nСкрипт остановлен пользователем")
    except Exception as e:
        print(f"Ошибка: {e}")
    finally:
        ser.close()
        print(f"COM-порт {COM_PORT} закрыт")


if __name__ == "__main__":
    # print(calculate_struct_size())
    main()