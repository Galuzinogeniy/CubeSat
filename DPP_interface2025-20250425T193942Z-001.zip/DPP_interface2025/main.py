import sys
import time
import os
import datetime
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QTextEdit, QFrame, QPushButton)
from PyQt5.QtCore import Qt, QTimer, pyqtSlot
from PyQt5.QtGui import QPainter, QColor, QFont, QPen, QBrush
import pyqtgraph as pg
from serial.tools import list_ports

from read_serial import SensorData


class TrubkiIndicator(QWidget):
    def __init__(self, label="T"):
        super().__init__()
        self.value = 0
        self.adc_value = 0
        self.cbk_value = 0
        self.label = label
        self.setMinimumSize(80, 80)
        self.setMaximumSize(80, 80)

    def setValue(self, flag_value, adc_value=0, cbk_value=0):
        self.value = flag_value
        self.adc_value = adc_value
        self.cbk_value = cbk_value
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(5, 5, -5, -5)
        painter.setPen(QPen(Qt.black, 2))

        if self.value != 0:
            painter.setBrush(QBrush(QColor(255, 50, 50)))
        else:
            painter.setBrush(QBrush(QColor(40, 40, 40)))

        painter.drawEllipse(rect)

        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(rect, Qt.AlignCenter, f"{self.label}\n{round(self.adc_value)}")


class SensorMonitorApp(QMainWindow):
    def __init__(self):
        super().__init__()

        self.sensor = SensorData()

        self.log_dir = "logs"
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        log_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_filename = os.path.join(self.log_dir, f"sensor_log_{log_timestamp}.txt")
        with open(self.log_filename, 'w', encoding='utf-8') as f:
            f.write(f"*** Начало сессии: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ***\n\n")

        self.setWindowTitle("Мониторинг телеметрии")
        self.setMinimumSize(1000, 700)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        top_panel = QHBoxLayout()

        self.connect_button = QPushButton("Подключиться")
        self.connect_button.setMinimumHeight(30)
        self.connect_button.clicked.connect(self.connect_to_port)
        top_panel.addWidget(self.connect_button)

        self.status_label = QLabel("Статус: не подключено")
        self.status_label.setStyleSheet("color: red;")
        top_panel.addWidget(self.status_label)

        self.log_button = QPushButton("Открыть лог-файл")
        self.log_button.setMinimumHeight(30)
        self.log_button.clicked.connect(self.open_log_file)
        top_panel.addWidget(self.log_button)

        self.log_path_label = QLabel(f"Лог-файл: {self.log_filename}")
        self.log_path_label.setStyleSheet("color: #AAAAAA; font-size: 9pt;")

        top_panel.addStretch()
        main_layout.addLayout(top_panel)

        main_layout.addWidget(self.log_path_label)

        content_layout = QHBoxLayout()

        charts_layout = QVBoxLayout()

        accel_chart = pg.PlotWidget(title="Акселерометр")
        accel_chart.showGrid(x=True, y=True)
        accel_chart.setLabel('left', 'Значение')
        accel_chart.setLabel('bottom', 'Время (с)')
        accel_chart.addLegend()
        self.accel_x_line = accel_chart.plot(pen=pg.mkPen('r', width=2), name='ax')
        self.accel_y_line = accel_chart.plot(pen=pg.mkPen('g', width=2), name='ay')
        self.accel_z_line = accel_chart.plot(pen=pg.mkPen('b', width=2), name='az')
        charts_layout.addWidget(accel_chart)

        gyro_chart = pg.PlotWidget(title="Гироскоп")
        gyro_chart.showGrid(x=True, y=True)
        gyro_chart.setLabel('left', 'Градусы/с')
        gyro_chart.setLabel('bottom', 'Время (с)')
        gyro_chart.addLegend()
        self.gyro_x_line = gyro_chart.plot(pen=pg.mkPen('r', width=2), name='gx')
        self.gyro_y_line = gyro_chart.plot(pen=pg.mkPen('g', width=2), name='gy')
        self.gyro_z_line = gyro_chart.plot(pen=pg.mkPen('b', width=2), name='gz')
        charts_layout.addWidget(gyro_chart)

        baro_chart = pg.PlotWidget(title="Барометр")
        baro_chart.showGrid(x=True, y=True)
        baro_chart.setLabel('left', 'Давление (гПа)')
        baro_chart.setLabel('bottom', 'Время (с)')
        self.pressure_line = baro_chart.plot(pen=pg.mkPen('c', width=2))
        charts_layout.addWidget(baro_chart)

        temp_chart = pg.PlotWidget(title="Температура")
        temp_chart.showGrid(x=True, y=True)
        temp_chart.setLabel('left', 'Температура (°C)')
        temp_chart.setLabel('bottom', 'Время (с)')
        self.temp_line = temp_chart.plot(pen=pg.mkPen('y', width=2))
        charts_layout.addWidget(temp_chart)

        adc_chart = pg.PlotWidget(title="Значения АЦП")
        adc_chart.showGrid(x=True, y=True)
        adc_chart.setLabel('left', 'Значение')
        adc_chart.setLabel('bottom', 'Время (с)')
        adc_chart.addLegend()
        self.adc1_line = adc_chart.plot(pen=pg.mkPen('r', width=2), name='ADC1')
        self.adc2_line = adc_chart.plot(pen=pg.mkPen('g', width=2), name='ADC2')
        self.adc3_line = adc_chart.plot(pen=pg.mkPen('b', width=2), name='ADC3')
        self.adc4_line = adc_chart.plot(pen=pg.mkPen('c', width=2), name='ADC4')
        self.adc5_line = adc_chart.plot(pen=pg.mkPen('m', width=2), name='ADC5')
        charts_layout.addWidget(adc_chart)

        content_layout.addLayout(charts_layout, 7)

        right_panel = QVBoxLayout()

        temp_indicators_widget = QWidget()
        temp_indicators_layout = QVBoxLayout(temp_indicators_widget)

        top_row = QHBoxLayout()
        top_row.addStretch()
        self.t3_indicator = TrubkiIndicator("T3")
        top_row.addWidget(self.t3_indicator)
        top_row.addStretch()
        temp_indicators_layout.addLayout(top_row)

        middle_row = QHBoxLayout()
        self.t2_indicator = TrubkiIndicator("T2")
        self.t1_indicator = TrubkiIndicator("T1")
        self.t4_indicator = TrubkiIndicator("T4")
        middle_row.addWidget(self.t2_indicator)
        middle_row.addWidget(self.t1_indicator)
        middle_row.addWidget(self.t4_indicator)
        temp_indicators_layout.addLayout(middle_row)

        bottom_row = QHBoxLayout()
        bottom_row.addStretch()
        self.t5_indicator = TrubkiIndicator("T5")
        bottom_row.addWidget(self.t5_indicator)
        bottom_row.addStretch()
        temp_indicators_layout.addLayout(bottom_row)

        right_panel.addWidget(QLabel("<b>Трубки Гейгера</b>"))
        right_panel.addWidget(temp_indicators_widget)

        right_panel.addWidget(QLabel("<b>Консоль</b>"))
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setStyleSheet("background-color: #1E1E1E; color: #FFFFFF; font-family: 'Courier New';")
        right_panel.addWidget(self.console)

        content_layout.addLayout(right_panel, 3)

        main_layout.addLayout(content_layout)

        self.timestamps = np.linspace(-30, 0, 100)
        self.accel_x_data = np.zeros(100)
        self.accel_y_data = np.zeros(100)
        self.accel_z_data = np.zeros(100)

        self.gyro_x_data = np.zeros(100)
        self.gyro_y_data = np.zeros(100)
        self.gyro_z_data = np.zeros(100)
        self.pressure_data = np.zeros(100)
        self.temperature_data = np.zeros(100)

        self.adc1_data = np.zeros(100)
        self.adc2_data = np.zeros(100)
        self.adc3_data = np.zeros(100)
        self.adc4_data = np.zeros(100)
        self.adc5_data = np.zeros(100)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_data)
        self.timer.start(100)

        self.available_ports = list_ports.comports()
        if self.available_ports:
            self.connect_to_port()

    def log_message(self, message):
        timestamp = time.strftime('%H:%M:%S')
        formatted_message = f"[{timestamp}] {message}\n\n"

        self.console.append(formatted_message)
        scrollbar = self.console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

        try:
            with open(self.log_filename, 'a', encoding='utf-8') as f:
                f.write(f"[{timestamp}] {message}\n\n")
        except Exception as e:
            self.console.append(f"[{timestamp}] Ошибка записи в лог-файл: {e}\n\n")

    def connect_to_port(self):
        if not self.sensor.connected:
            connected = self.sensor.connect_to_port("COM11")
            if connected:
                self.status_label.setText("Статус: подключено")
                self.status_label.setStyleSheet("color: green;")
                self.connect_button.setText("Отключиться")
                self.log_message("Успешное подключение к порту COM11")
            else:
                self.log_message("Не удалось подключиться к порту COM11. Используются статичные значения.")
        else:
            self.sensor.close()
            self.status_label.setText("Статус: не подключено")
            self.status_label.setStyleSheet("color: red;")
            self.connect_button.setText("Подключиться")
            self.log_message("Отключено от порта")

    def open_log_file(self):
        try:
            if sys.platform == 'win32':
                os.startfile(self.log_filename)
            self.log_message(f"Открытие лог-файла: {self.log_filename}")
        except Exception as e:
            self.log_message(f"Ошибка при открытии лог-файла: {e}")

    def update_data(self):
        data = self.sensor.read_data()
        current_time = time.time()

        if not hasattr(self, 'last_update_time'):
            self.last_update_time = current_time
            self.prev_data = data.copy()
            self.current_data = data.copy()

        elapsed = current_time - self.last_update_time

        if elapsed >= 0.9:
            self.prev_data = self.current_data.copy()
            self.current_data = data.copy()
            self.last_update_time = current_time

        factor = min(1.0, elapsed / 1.0)

        interpolated_data = {}

        numeric_keys = ['ax', 'ay', 'az', 'gx', 'gy', 'gz', 'pressure', 'temperature',
                        'adc1', 'adc2', 'adc3', 'adc4', 'adc5']

        for key in numeric_keys:
            if key in self.prev_data and key in self.current_data:
                interpolated_data[key] = self.prev_data[key] + factor * (self.current_data[key] - self.prev_data[key])

        for key in data:
            if key not in interpolated_data:
                interpolated_data[key] = data[key]

        self.timestamps = np.roll(self.timestamps, -1)
        self.timestamps[-1] = self.timestamps[-2] + 1

        self.accel_x_data = np.roll(self.accel_x_data, -1)
        self.accel_x_data[-1] = interpolated_data['ax']

        self.accel_y_data = np.roll(self.accel_y_data, -1)
        self.accel_y_data[-1] = interpolated_data['ay']

        self.accel_z_data = np.roll(self.accel_z_data, -1)
        self.accel_z_data[-1] = interpolated_data['az']

        self.gyro_x_data = np.roll(self.gyro_x_data, -1)
        self.gyro_x_data[-1] = interpolated_data['gx']

        self.gyro_y_data = np.roll(self.gyro_y_data, -1)
        self.gyro_y_data[-1] = interpolated_data['gy']

        self.gyro_z_data = np.roll(self.gyro_z_data, -1)
        self.gyro_z_data[-1] = interpolated_data['gz']

        self.pressure_data = np.roll(self.pressure_data, -1)
        self.pressure_data[-1] = interpolated_data['pressure']

        self.temperature_data = np.roll(self.temperature_data, -1)
        self.temperature_data[-1] = interpolated_data['temperature']

        self.adc1_data = np.roll(self.adc1_data, -1)
        self.adc1_data[-1] = interpolated_data['adc1']

        self.adc2_data = np.roll(self.adc2_data, -1)
        self.adc2_data[-1] = interpolated_data['adc2']

        self.adc3_data = np.roll(self.adc3_data, -1)
        self.adc3_data[-1] = interpolated_data['adc3']

        self.adc4_data = np.roll(self.adc4_data, -1)
        self.adc4_data[-1] = interpolated_data['adc4']

        self.adc5_data = np.roll(self.adc5_data, -1)
        self.adc5_data[-1] = interpolated_data['adc5']

        self.accel_x_line.setData(self.timestamps, self.accel_x_data)
        self.accel_y_line.setData(self.timestamps, self.accel_y_data)
        self.accel_z_line.setData(self.timestamps, self.accel_z_data)

        self.gyro_x_line.setData(self.timestamps, self.gyro_x_data)
        self.gyro_y_line.setData(self.timestamps, self.gyro_y_data)
        self.gyro_z_line.setData(self.timestamps, self.gyro_z_data)

        self.pressure_line.setData(self.timestamps, self.pressure_data)
        self.temp_line.setData(self.timestamps, self.temperature_data)

        self.adc1_line.setData(self.timestamps, self.adc1_data)
        self.adc2_line.setData(self.timestamps, self.adc2_data)
        self.adc3_line.setData(self.timestamps, self.adc3_data)
        self.adc4_line.setData(self.timestamps, self.adc4_data)
        self.adc5_line.setData(self.timestamps, self.adc5_data)

        self.t1_indicator.setValue(data['flag0'], interpolated_data['adc1'], data['cbk1'])
        self.t2_indicator.setValue(data['flag1'], interpolated_data['adc2'], data['cbk2'])
        self.t3_indicator.setValue(data['flag2'], interpolated_data['adc3'], data['cbk3'])
        self.t4_indicator.setValue(data['flag3'], interpolated_data['adc4'], data['cbk4'])
        self.t5_indicator.setValue(data['flag4'], interpolated_data['adc5'], data['cbk5'])

        # if int(self.timestamps[-1] * 10) % 10 == 0:
        status = "Подключено" if data['connected'] else "Не подключено (статичные данные)"
        sensor_info = (
            f"Статус: {status}\n"
            f"Время сенсора: {data['timestamp']} мс\n"
            f"Давление: {data['pressure']:.2f} гПа, Температура: {data['temperature']:.2f} °C\n"
            f"Акселерометр: ax={data['ax']:.2f}, ay={data['ay']:.2f}, az={data['az']:.2f}\n"
            f"Гироскоп: gx={data['gx']:.2f}, gy={data['gy']:.2f}, gz={data['gz']:.2f}\n"
            f"Высота: {(986 - data['pressure']) // 1} м\n"
            f"Значения АЦП: adc1={data['adc1']}, adc2={data['adc2']}, adc3={data['adc3']}, "
            f"adc4={data['adc4']}, adc5={data['adc5']}\n"
            f"Колбэки: cbk1={data['cbk1']}, cbk2={data['cbk2']}, cbk3={data['cbk3']}, "
            f"cbk4={data['cbk4']}, cbk5={data['cbk5']}\n"
            f"Флаги трубок: flag0={data['flag0']}, flag1={data['flag1']}, flag2={data['flag2']}, "
            f"flag3={data['flag3']}, flag4={data['flag4']}"
        )

        full_log_info = sensor_info + f"\n" + (
            f"Магнитометр: mx={data['mx']}, my={data['my']}, mz={data['mz']}"
        )

        self.log_message(full_log_info)

    def closeEvent(self, event):
        try:
            with open(self.log_filename, 'a', encoding='utf-8') as f:
                f.write(f"\n*** Конец сессии: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ***\n")
        except Exception as e:
            print(f"Ошибка записи в лог-файл при закрытии: {e}")

        self.sensor.close()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    palette = app.palette()
    palette.setColor(palette.Window, QColor(53, 53, 53))
    palette.setColor(palette.WindowText, Qt.white)
    palette.setColor(palette.Base, QColor(25, 25, 25))
    palette.setColor(palette.AlternateBase, QColor(53, 53, 53))
    palette.setColor(palette.ToolTipBase, Qt.white)
    palette.setColor(palette.ToolTipText, Qt.white)
    palette.setColor(palette.Text, Qt.white)
    palette.setColor(palette.Button, QColor(53, 53, 53))
    palette.setColor(palette.ButtonText, Qt.white)
    palette.setColor(palette.BrightText, Qt.red)
    palette.setColor(palette.Link, QColor(42, 130, 218))
    palette.setColor(palette.Highlight, QColor(42, 130, 218))
    palette.setColor(palette.HighlightedText, Qt.black)
    app.setPalette(palette)

    window = SensorMonitorApp()
    window.show()
    sys.exit(app.exec_())