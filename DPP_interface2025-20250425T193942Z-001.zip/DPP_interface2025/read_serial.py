import serial
import time
import random
from vis import unpack_packet, find_preamble, STRUCT_SIZE

class SensorData:
    def __init__(self):
        self.timestamp = 0
        self.pressure = 0.0
        self.temperature = 0.0
        self.mx = 0
        self.my = 0
        self.mz = 0
        self.gx = 0.0
        self.gy = 0.0
        self.gz = 0.0
        self.ax = 0.0
        self.ay = 0.0
        self.az = 0.0
        self.adc1 = 0
        self.adc2 = 0
        self.adc3 = 0
        self.adc4 = 0
        self.adc5 = 0
        self.cbk1 = 0
        self.cbk2 = 0
        self.cbk3 = 0
        self.cbk4 = 0
        self.cbk5 = 0
        self.cbk6 = 0
        self.cbk7 = 0
        self.cbk8 = 0
        self.cbk9 = 0
        self.cbk10 = 0
        self.cbk11 = 0
        self.cbk12 = 0
        self.cbk13 = 0
        self.cbk14 = 0
        self.cbk15 = 0
        self.callback_time1 = 0
        self.callback_time2 = 0
        self.callback_time3 = 0
        self.callback_time4 = 0
        self.callback_time4 = 0
        self.callback_time5 = 0
        self.flag0 = 0
        self.flag1 = 0
        self.flag2 = 0
        self.flag3 = 0
        self.flag4 = 0
        self.connected = False
        self.serial_port = None
        self.port_name = "COM11"
        self.baudrate = 9600
        self.timeout = 1
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 30
        self.reconnect_delay = 2

    def connect_to_port(self, port="COM11", baudrate=9600, timeout=1):
        self.port_name = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.reconnect_attempts = 0
        return self._try_connect()

    def _try_connect(self):
        try:
            self.serial_port = serial.Serial(self.port_name, self.baudrate, timeout=self.timeout)
            self.connected = True
            self.reconnect_attempts = 0
            print(f"Успешное подключение к порту {self.port_name}")
            return True
        except Exception as e:
            self.connected = False
            print(f"Ошибка подключения к порту {self.port_name}: {e}")
            return False

    def _attempt_reconnect(self):
        if self.reconnect_attempts < self.max_reconnect_attempts:
            self.reconnect_attempts += 1
            print(f"Попытка переподключения {self.reconnect_attempts}/{self.max_reconnect_attempts}...")
            time.sleep(self.reconnect_delay)
            if self._try_connect():
                print("Переподключение успешно!")
                return True
            else:
                print(
                    f"Переподключение не удалось. Осталось попыток: {self.max_reconnect_attempts - self.reconnect_attempts}")
                return False
        else:
            print(f"Превышено максимальное количество попыток переподключения ({self.max_reconnect_attempts})")
            self._use_random_values()
            return False

    def _use_random_values(self):
        self.flag0 = 1 if random.random() > 0.8 else 0
        self.flag1 = 1 if random.random() > 0.8 else 0
        self.flag2 = 1 if random.random() > 0.8 else 0
        self.flag3 = 1 if random.random() > 0.8 else 0
        self.flag4 = 1 if random.random() > 0.8 else 0
        self.cbk1 = 1 if random.random() > 0.7 else 0
        self.cbk2 = 1 if random.random() > 0.7 else 0
        self.cbk3 = 1 if random.random() > 0.7 else 0
        self.cbk4 = 1 if random.random() > 0.7 else 0
        self.cbk5 = 1 if random.random() > 0.7 else 0
        self.timestamp = int(time.time() * 1000)
        print("Используются случайные значения после неудачных попыток переподключения")

    def read_data(self):
        if not self.connected:
            reconnected = self._attempt_reconnect()
            if not reconnected:
                return self._get_current_values()
        try:
            buffer = bytearray()
            while True:
                # Читаем доступные данные

                if self.serial_port.in_waiting > 0:
                    new_data = self.serial_port.read(self.serial_port.in_waiting)
                    # new_data = 0
                    buffer.extend(new_data)
                else:
                    time.sleep(0.0001)  # Ждем немного, если данных нет
                    continue

                # Обрабатываем полные пакеты
                # packet_data = dict()
                # Ищем преамбулу в буфере
                preamble_index = find_preamble(buffer)

                if preamble_index == -1:
                    # Преамбула не найдена, сохраняем последние байты на случай разделения преамбулы
                    if len(buffer) > 3:
                        buffer = buffer[-3:]
                    continue

                # Если преамбула не в начале, обрезаем буфер
                if preamble_index > 0:
                    buffer = buffer[preamble_index:]

                # Проверяем, есть ли у нас полный пакет
                if len(buffer) < STRUCT_SIZE:
                    continue


                # У нас есть полный пакет с корректной преамбулой
                packet_data = buffer[:STRUCT_SIZE]
                buffer = buffer[STRUCT_SIZE:]  # Удаляем обработанные данные
                line = unpack_packet(packet_data)
                if len(line) >= 0:
                    self.timestamp = line['time']
                    self.pressure = line['pressure']
                    self.temperature = line['temperature']
                    self.mx = line['mx']
                    self.my = line['my']
                    self.mz = line['mz']
                    self.gx = line['gx']
                    self.gy = line['gy']
                    self.gz = line['gz']
                    self.ax = line['ax']
                    self.ay = line['ay']
                    self.az = line['az']
                    self.adc1,self.adc2,self.adc3,self.adc4,self.adc5 = line['adc_values']
                    self.cbk1, self.cbk2, self.cbk3, self.cbk4, self.cbk5, self.cbk6, self.cbk7, self.cbk8, self.cbk9, self.cbk10, self.cbk11, self.cbk12, self.cbk13, self.cbk14, self.cbk15 = line['cbks']
                    self.callback_time1, self.callback_time2, self.callback_time3, self.callback_time4, self.callback_time5  = line['callback_times']
                    self.flag0, self.flag1, self.flag2, self.flag3, self.flag4 = line['flags']
                    print("Данные успешно прочитаны с COM-порта")
                    break
                else:
                    print(f"Неправильный формат данных: {line}")
        except Exception as e:
            print(f"Ошибка при чтении данных: {e}")
            self.close()
            self.connected = False
            self._attempt_reconnect()

        return self._get_current_values()

    def _get_current_values(self):
        return {
            'timestamp': self.timestamp,
            'pressure': self.pressure,
            'temperature': self.temperature,
            'mx': self.mx,
            'my': self.my,
            'mz': self.mz,
            'gx': self.gx,
            'gy': self.gy,
            'gz': self.gz,
            'ax': self.ax,
            'ay': self.ay,
            'az': self.az,
            'adc1': self.adc1,
            'adc2': self.adc2,
            'adc3': self.adc3,
            'adc4': self.adc4,
            'adc5': self.adc5,
            'cbk1': self.cbk1,
            'cbk2': self.cbk2,
            'cbk3': self.cbk3,
            'cbk4': self.cbk4,
            'cbk5': self.cbk5,
            'callback_time1': self.callback_time1,
            'callback_time2': self.callback_time2,
            'callback_time3': self.callback_time3,
            'callback_time4': self.callback_time4,
            'callback_time5': self.callback_time5,
            'flag0': self.flag0,
            'flag1': self.flag1,
            'flag2': self.flag2,
            'flag3': self.flag3,
            'flag4': self.flag4,
            'connected': self.connected
        }

    def close(self):
        if self.connected and self.serial_port:
            self.serial_port.close()
            self.connected = False
            print("Соединение с COM-портом закрыто")


if __name__ == "__main__":
    sensor = SensorData()
    sensor.connect_to_port("COM11")
    try:
        while True:
            data = sensor.read_data()
            print("\nТекущие значения:")
            print(f"Метка времени: {data['timestamp']} мс")
            print(f"Давление: {data['pressure']:.2f} гПа")
            print(f"Температура: {data['temperature']:.2f} °C")
            print(f"Магнитометр: mx={data['mx']}, my={data['my']}, mz={data['mz']}")
            print(f"Гироскоп: gx={data['gx']:.2f}, gy={data['gy']:.2f}, gz={data['gz']:.2f}")
            print(f"Акселерометр: ax={data['ax']:.2f}, ay={data['ay']:.2f}, az={data['az']:.2f}")
            print(
                f"Значения АЦП: adc1={data['adc1']}, adc2={data['adc2']}, adc3={data['adc3']}, adc4={data['adc4']}, adc5={data['adc5']}")
            print(
                f"Колбэки: cbk1={data['cbk1']}, cbk2={data['cbk2']}, cbk3={data['cbk3']}, cbk4={data['cbk4']}, cbk5={data['cbk5']}")
            print(
                f"Флаги: flag0={data['flag0']}, flag1={data['flag1']}, flag2={data['flag2']}, flag3={data['flag3']}, flag4={data['flag4']}")
            print(
                f"Времена обратного вызова: cb1={data['callback_time1']}, cb2={data['callback_time2']}, cb3={data['callback_time3']}, cb4={data['callback_time4']}, cb5={data['callback_time5']}")
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\nПрограмма остановлена пользователем")
    finally:
        sensor.close()