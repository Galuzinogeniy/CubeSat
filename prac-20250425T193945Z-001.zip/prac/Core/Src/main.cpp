/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "MS5611.h"
#include "LM75A.h"
#include "LSM6DS3.h"
#include "LIS3MDL.h"
#include "SD.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

int flg = 0;
int callback_counter = 0;
uint32_t prevTLMtime = 0;
uint32_t prevITtime = 0;
struct packet{
	  uint32_t preambula = 2704;
	  uint32_t time;
	  float pressure;
	  float temperature;
	  int16_t mx; int16_t my; int16_t mz;
	  float gx; float gy; float gz;

	  float ax; float ay; float az;
	  bool flag0;
	  bool flag1;
	  bool flag2;
	  bool flag3;
	  bool flag4;
	  uint16_t adc_values[5];
	  uint8_t cbks[15];
	  uint32_t callback_times[5];
};
packet pack;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_Base_Start(&htim2);

  HAL_NVIC_DisableIRQ(EXTI9_5_IRQn);
  HAL_NVIC_DisableIRQ(EXTI0_IRQn);
  HAL_NVIC_DisableIRQ(EXTI1_IRQn);
  HAL_NVIC_DisableIRQ(EXTI2_IRQn);
  HAL_NVIC_DisableIRQ(EXTI3_IRQn);
  IntroStratLib::SD sd;
  sd.Init();
  IntroStratLib::SD::File file("LOG.txt", FA_WRITE | FA_OPEN_APPEND);
  file.Init();

  IntroStratLib::MS5611 bar(&hi2c1, 0x77);
  IntroStratLib::LIS3MDL magn(&hi2c1, 0x1E);
  IntroStratLib::LSM6DS3 gyro(&hi2c1, 0x6A);
  IntroStratLib::LM75A term(&hi2c1, 0x4A);

//  uint64_t test[100] = {0};

  char data[100000];
  char sm = '0';
  packet pack1 = {
      .time = 66666,
      .pressure = 78.7,
      .temperature = 656.6,
      .mx = 554,
      .my = 545,
      .mz = 54,
      .gx = 594.0,
      .gy = 6.04,
      .gz = 644.0,
      .ax = 123,
      .ay = 343,
      .az = 954,
      .flag0 = 1,
      .flag1 = 1,
      .flag2 = 1,
      .flag3 = 1,
      .flag4 = 0,
      .adc_values = {1, 2, 3, 4, 5},
      .cbks = {44, 54, 77, 54, 6, 43, 11, 32, 77, 64, 111, 73, 23, 45, 12},
      .callback_times = {12121, 222343, 543345, 53223, 5434}
  };
    


//  HAL_NVIC_DisableIRQ(TIM2_IRQn);

  if (bar.Init() != HAL_OK){
  	HAL_UART_Transmit(&huart1, (uint8_t*)"Barometer not initialized\n", strlen("Barometer not initialized\n"), 1000);
  	file.Write("Barometer not initialized\n");
  }
  else{
	file.Write("Barometer initialized\n");
  }

  if (gyro.InitAccel(1) != HAL_OK){
    HAL_UART_Transmit(&huart1, (uint8_t*)"Accelerometer not initialized\n", strlen("Accelerometer not initialized\n"), 1000);
    file.Write("Accelerometer not initialized\n");
  }
  else{
    file.Write("Accelerometer initialized\n");
  }

  if (gyro.InitGyro(1) != HAL_OK){
    HAL_UART_Transmit(&huart1, (uint8_t*)"Gyroscope not initialized\n", strlen("Gyroscope not initialized\n"), 1000);
    file.Write("Gyroscope not initialized\n");
  }
  else{
	file.Write("Gyroscope initialized\n");
  }

  if (magn.Init() != HAL_OK){
    HAL_UART_Transmit(&huart1, (uint8_t*)"Magnetometer not initialized\n", strlen("Magnetometer not initialized\n"), 1000);
    file.Write("Magnetometer not initialized\n");
  }
  else{
    file.Write("Magnetometer initialized\n");
  }

  if (term.Init() != HAL_OK){
    HAL_UART_Transmit(&huart1, (uint8_t*)"Termometer not initialized\n", strlen("Termometer not initialized\n"), 1000);
    file.Write("Termometer not initialized\n");
  }
  else{
    file.Write("Termometer initialized\n");
  }

  if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)pack.adc_values, 5) != HAL_OK) {
    HAL_UART_Transmit(&huart1, (uint8_t*)"ADC not started\n", strlen("ADC not started\n"), 1000);
    file.Write("ADC not started\n");
  }
  else{
    file.Write("ADC started\n");
  }
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

//  sprintf(data, "ADC State: %d\n", HAL_ADC_GetState(&hadc1));
//  HAL_UART_Transmit(&huart1, (uint8_t*)data, strlen(data), 1000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  HAL_UART_Receive(&huart1, (uint8_t*)&sm, 1, 100);
	  if(HAL_GetTick() > 10000 || sm == 's' || 1){
		  flg = 1;
	  }
	  if(HAL_GetTick() > 100000 || flg == 1){
		  if(HAL_GetTick() - prevTLMtime > 10000){
			  HAL_NVIC_DisableIRQ(EXTI9_5_IRQn);
			  HAL_NVIC_DisableIRQ(EXTI0_IRQn);
			  HAL_NVIC_DisableIRQ(EXTI1_IRQn);
			  HAL_NVIC_DisableIRQ(EXTI2_IRQn);
			  HAL_NVIC_DisableIRQ(EXTI3_IRQn);
			  pack.pressure = bar.GetPressure();
			  pack.temperature = term.GetTemperature();
			  pack.mx = magn.RawMX(); pack.my = magn.RawMY(); pack.mz = magn.RawMZ();
			  pack.gx = gyro.GX(); pack.gy = gyro.GY(); pack.gz = gyro.GZ();
			  pack.ax = gyro.AX(); pack.ay = gyro.AY(); pack.az = gyro.AZ();
			  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)pack.adc_values, 5);
			  pack.time = HAL_GetTick();
			  sprintf(data, "%lu;%.2f;%.2f;%d;%d;%d;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%d;%d;%d;%d;%d;%d;%d;%d;%d;%d;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%d;%d;%d;%d;%d\n",
			  							  HAL_GetTick(), pack.pressure, pack.temperature, pack.mx, pack.my, pack.mz, pack.gx, pack.gy, pack.gz, pack.ax, pack.ay, pack.az,
										  pack.adc_values[0], pack.adc_values[1], pack.adc_values[2], pack.adc_values[3], pack.adc_values[4],
										  pack.cbks[0], pack.cbks[1], pack.cbks[2], pack.cbks[3], pack.cbks[4], 0, 0,
										  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
										  pack.flag0, pack.flag1, pack.flag2, pack.flag3, pack.flag4);
			  HAL_UART_Transmit(&huart1, (uint8_t*)&pack, sizeof(pack), 1000);
			  file.Write(data);
			  prevTLMtime = HAL_GetTick();
			  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
			  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
			  HAL_NVIC_EnableIRQ(EXTI1_IRQn);
			  HAL_NVIC_EnableIRQ(EXTI2_IRQn);
			  HAL_NVIC_EnableIRQ(EXTI3_IRQn);
		  }
	  }

	  if ((pack.flag0||pack.flag1||pack.flag2||pack.flag3||pack.flag4) && HAL_GetTick() - prevITtime > 0){
		  HAL_NVIC_DisableIRQ(EXTI9_5_IRQn);
		  HAL_NVIC_DisableIRQ(EXTI0_IRQn);
		  HAL_NVIC_DisableIRQ(EXTI1_IRQn);
		  HAL_NVIC_DisableIRQ(EXTI2_IRQn);
		  HAL_NVIC_DisableIRQ(EXTI3_IRQn);
		  prevITtime = HAL_GetTick();
		  sprintf(data, "%lu;%.2f;%.2f;%d;%d;%d;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%d;%d;%d;%d;%d;%d;%d;%d;%d;%d;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%d;%d;%d;%d;%d\n",
		  							  HAL_GetTick(), pack.pressure, pack.temperature, pack.mx, pack.my, pack.mz, pack.gx, pack.gy, pack.gz, pack.ax, pack.ay, pack.az,
									  pack.adc_values[0], pack.adc_values[1], pack.adc_values[2], pack.adc_values[3], pack.adc_values[4],
									  pack.cbks[0], pack.cbks[1], pack.cbks[2], pack.cbks[3], pack.cbks[4], 0, 0,
									  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
									  pack.flag0, pack.flag1, pack.flag2, pack.flag3, pack.flag4);
		  file.Write(data);
		  HAL_UART_Transmit(&huart1, (uint8_t*)&pack, sizeof(pack), 1000);
		  pack.flag0 = 0; pack.flag1 = 0; pack.flag2 = 0; pack.flag3 = 0; pack.flag4 = 0;
		  pack.cbks[0] = 0; pack.cbks[1] = 0; pack.cbks[2] = 0; pack.cbks[3] = 0; pack.cbks[4] = 0;
		  pack.callback_times[0] = 0; pack.callback_times[1] = 0; pack.callback_times[2] = 0; pack.callback_times[3] = 0; pack.callback_times[4] = 0;
		  callback_counter = 0;
		  htim2.Instance->CNT=0;
		  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
		  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
		  HAL_NVIC_EnableIRQ(EXTI1_IRQn);
		  HAL_NVIC_EnableIRQ(EXTI2_IRQn);
		  HAL_NVIC_EnableIRQ(EXTI3_IRQn);
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 64;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 16;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
//	if (hadc->Instance == hadc1.Instance) {
//	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
//    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_values, 5);
	pack.callback_times[callback_counter] = htim2.Instance->CNT;
	if(GPIO_Pin == GPIO_PIN_0){
		pack.flag0 = 1;
		pack.cbks[callback_counter] = 1;
	}
	else if(GPIO_Pin == GPIO_PIN_1){
		pack.flag1 = 1;
		pack.cbks[callback_counter] = 2;
	}
	else if(GPIO_Pin == GPIO_PIN_2){
		pack.flag2 = 1;
		pack.cbks[callback_counter] = 3;
	}
	else if(GPIO_Pin == GPIO_PIN_3){
		pack.flag3 = 1;
		pack.cbks[callback_counter] = 4;
	}
	else{
		pack.flag4 = 1;
		pack.cbks[callback_counter] = 5;
	}
	callback_counter++;
//	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_values, 5);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
